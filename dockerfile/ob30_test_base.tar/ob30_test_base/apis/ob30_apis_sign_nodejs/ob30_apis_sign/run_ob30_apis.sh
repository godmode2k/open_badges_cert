#!/bin/sh


node ob30_api_sign_server_express.js

